// Courtesy of Almas Baimagambetov's code
// https://www.youtube.com/watch?v=luUeSnIYjJo 
// Adapted for repl.it

public interface Crypto {

	byte[] encrypt(byte[] data);
	byte[] decrypt(byte[] data);
  
}